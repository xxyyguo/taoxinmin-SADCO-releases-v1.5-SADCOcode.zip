function [xapp,xtest,meanxapp,stdxapp] = normalizemeanstd(xapp,xtest,meanx,stdx)

% USAGE
% 
%  [xapp,xtest,meanxapp,stdxapp] = normalizemeanstd(xapp,xtest)
%
% normalize inputs and output mean and standard deviation to 0 and 1
%
% 
tol=1e-5;



nbsuppress=0;
if nargin <3%如果输入的项目少于3个（输入没给平均值和标准差）
    meanxapp=mean(xapp);%默认的是求各列的均值，mean(xapp,2)，求得是各行的均值
   stdxapp=std(xapp);  %默认的是求各列的均值，std(xapp,2)，求得是各行的均值

else
    meanxapp=meanx;
    stdxapp=stdx;
end;
nbxapp=size(xapp,1); %行数（样本数）
indzero=find(abs(stdxapp)<tol);%找到标准差小于0的列数
%keyboard
if ~isempty(indzero)%如果有标准差小于0的，把它标准差调为1

    stdxapp(indzero)=1;

end;
nbvar=size(xapp,2);%列数（特征数）

xapp= (xapp - ones(nbxapp,1)*meanxapp)./ (ones(nbxapp,1)*stdxapp);%化为标准形式平均值和标准差在0到1之间

if nargin >1 & ~isempty(xtest)%输入项目大于1，且xtest不为空
    nbxtest=size(xtest,1);%利用原来的mean，std求解标准化后的xtest
    xtest= (xtest - ones(nbxtest,1)*meanxapp)./ (ones(nbxtest,1)*stdxapp );
else
    xtest=[];
end;