function [data,datatest,datamean,datastand]=normalize(data,datatest,datamean,datastand)
tol=1e-5;
 if nargin<3
    meandata=mean(data);
	standarddata=std(data);
	else
	meandata=datamean;
	standarddata=datastand;
	end
	
	rowdata=size(data,1);
	indexdata=find(abs(standarddata)<tol);
	if ~isempty(indexdata)
	standarddata(indexdata)=1;
	end
	
	data=(data-ones(rowdata,1).*meandata)./(ones(rowdata,1).*standarddata);
	   
