function [dradius] = calradiousdemo(i,ilabel,majlabel,minlabel,...
			minENNdist,minenemykneigor,majENNdist,majenemykneigor)
%只适合2类数据集
%majmindistmax-----distance matrix [num-majority x num-minority ]
% i----ith data indice----- the indice of the sample in it class to be used 
%%ilabel-indict which class it belongs to
% matrix,
% dradius ---maj datasets
	%IR = size(majENNdist,1)/size(minENNdist,1);
	%tha = 1-1/(1+exp(-(IR-1)));
	tha = 0.5;
	if ilabel == minlabel
		nej = minenemykneigor(i);
		dij = minENNdist(i);
		jlabel =  majlabel;
		if ( i == majenemykneigor(nej))
			dradius = dij*tha;
			return ;
		else
			dt = calradious(nej,jlabel,majlabel,minlabel,...
				minENNdist,minenemykneigor,majENNdist,majenemykneigor)	;
			dradius = dij-dt;
			return ;	
		end
	else
		nej = majenemykneigor(i);
		dij = majENNdist(i);
		jlabel =  minlabel;
		if ( i == minenemykneigor(nej))
			dradius = dij*(1-tha);
			return ;
		else
			dt = calradious(nej,jlabel,majlabel,minlabel,...
				minENNdist,minenemykneigor,majENNdist,majenemykneigor)	;
			dradius = dij-dt;
			return ;			
		end
	end
	
	
	
	