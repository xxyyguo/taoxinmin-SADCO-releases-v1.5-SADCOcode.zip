		close all
		clear all
		clc
		
		
		data_all=[
		1 0.9 1
		3 2.1 -1;
		0.5 0.5 -1;
        ];
		
		data_all(:,1:end-1) = normalizemeanstd(data_all(:,1:end-1));
		
		labx = data_all(:,3);
		
		
		data_allmajority = data_all(find(labx==1),:);
		data_allminority = data_all(find(labx==-1),:);
		IMratio = size(data_allmajority,1)/size(data_allminority,1);
		
		
        figure
	    hold on
		plot(data_allmajority(:,1), data_allmajority(:,2), 'b^', 'LineWidth',2, 'MarkerSize', 7);
		plot(data_allminority(:,1),  data_allminority(:,2), 'g+', 'LineWidth',2, 'MarkerSize', 7);
        
		legend('majority instances','minority instances','overlapped instances','KNN');
		
		[minENNdist,minenemykneigor,majENNdist,majenemykneigor,majmindistmax,cputime] = ...
			kNNenemyPoint(data_allminority(:,1:end-1),data_allmajority(:,1:end-1));
		
		majlabel = 1;
		minlabel = -1;
		
		majdradious = [];
		for i=1:size(data_allmajority,1)
			ilabel = majlabel;
		% for i=1:size(data_allminority,1)
			% ilabel = minlabel;		
			[dradius] = calradiousdemo(i,ilabel,majlabel,minlabel,...
				minENNdist,minenemykneigor,majENNdist,majenemykneigor)	;
				majdradious = [majdradious;[i,data_allmajority(i,1:end-1),dradius]];
			% mindradious = [mindradious;[i,data_allminority(i,1:end-1),dradius]];
		end
		rectangle('Position',[data_allmajority(1,1)-majdradious(1,end),...
			  data_allmajority(1,1)-majdradious(1,end),2*majdradious(1,end),2*majdradious(1,end)],'Curvature',[1,1],'EdgeColor','r');
			  axis equal;
			  pause;
		rectangle('Position',[data_allmajority(1,1)-majdradious(1,end),...
			  data_allmajority(1,1)-majdradious(1,end),2*majdradious(1,end),2*majdradious(1,end)],'Curvature',[1,1],'EdgeColor','r');
			  axis equal;
		