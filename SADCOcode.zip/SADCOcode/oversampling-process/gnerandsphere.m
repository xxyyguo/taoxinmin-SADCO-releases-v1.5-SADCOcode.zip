function Y = gnerandsphere(center,d,N,r)
    random_directions = randn(N,d);
    random_directions = random_directions./sqrt(sum(random_directions.^2,2)); 
	% 使得超球的半径为1，单位向量，先生成一个随机方向（单位）
    %random_radii = (r*rand(N,1)).^(1/d);%其次生成一个随机距离
	% random_radii = (r*ones(N,1)).^(1/d);%其次生成一个随机距离
    %random_radii =r*ones(N,1);
	random_radii =r*rand(N,1);
	
    Y = random_directions.* repmat(random_radii,1,d);
    Y = repmat(center,N,1)+Y;
end