clc, clear
r = 1;
center = [2 2];
X = gnerandsphere(center,2,50,r); % 2表示维数，50000表示样本数

s = scatter(center(:,1),center(:,2),50,'r','p','filled');
s.LineWidth = 10.6;
hold on;
s = scatter(X(:,1),X(:,2),5,'d');
s.MarkerEdgeColor = 'b';
s.MarkerFaceColor = [0 0.5 0.5];
s.LineWidth = 2.6;
rectangle('Position',[center(1)-r,...
			  center(2)-r,2*r,...
			     2*r],'Curvature',[1,1],'EdgeColor','r');
			  axis equal;

	


clc, clear
r = 2;%半径
center = [2 2 2];%球心
X = gnerandsphere(center,3,50,r); % 2表示维数，50000表示样本数
figure	
s = scatter3(X(:,1),X(:,2),X(:,3),5,'d');
s.MarkerEdgeColor = 'b';
s.MarkerFaceColor = [0 0.5 0.5];
s.LineWidth = 2.6;
		  axis equal;
		
hold on
%下面开始画
[x,y,z]=sphere;
m = mesh(r*x+center(1),r*y+center(2),r*z+center(3));
%m.FaceColor = 'flat';
m.FaceAlpha = 0.5;
m.EdgeColor = 'none';
axis equal