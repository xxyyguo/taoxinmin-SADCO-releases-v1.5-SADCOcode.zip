        close all
		clear all
		clc
	%		
		load data_all.txt
		
		data_all(:,1:end-1) = normalizemeanstd(data_all(:,1:end-1));
		dim = size(data_all(:,1:end-1),2);
		labx = data_all(:,3);
		
		
		data_allmajority = data_all(find(labx==1),:);
		data_allminority = data_all(find(labx==-1),:);
		IMratio = size(data_allmajority,1)/size(data_allminority,1);
		
		
        figure
	    hold on
		Malhandle = plot(data_allmajority(:,1), data_allmajority(:,2),... 
		'b^', 'LineWidth',2, 'MarkerSize', 7);
		Minhandle = plot(data_allminority(:,1),  data_allminority(:,2),... 
		'g+', 'LineWidth',2, 'MarkerSize', 7);
	    
		[minENNdist,minenemykneigor,majENNdist,majenemykneigor,majmindistmax,cputime] = ...
			kNNenemyPoint(data_allminority(:,1:end-1),data_allmajority(:,1:end-1));
		legend([Malhandle Minhandle],{'majority instances','minority instances'});
		
		%多数类和少数类的class label
		majlabel = 1;
		minlabel = -1;
		
		
		drawminCircleFlag = 0;
		%是否绘制少数类的hypersphere
		mindradious = [];
		%保持每一个少数类样本的hypersphere的信息-[序号+数据点dim+半径]
		
		for i=1:size(data_allminority,1)
			ilabel = minlabel;		
			[dradius] = calradious(i,ilabel,majlabel,minlabel,...
				minENNdist,minenemykneigor,majENNdist,majenemykneigor)	;
			mindradious = [mindradious;[i,data_allminority(i,1:end-1),dradius]];
			if drawminCircleFlag == 1 %是否绘制圆，二维才行
				rectangle('Position',[data_allminority(i,1)-dradius,...
				data_allminority(i,2)-dradius,2*dradius,2*dradius],'Curvature',[1,1],'EdgeColor','r');
				axis equal;
				pause(2);
			end
		end
		
	%%%%%%%%%%%%%%%%为每一个少数类样本生成一个hypersphere%%%%%%%%%%
		
		%合并
		data = data_allminority(:,1:end-1);
		[mindradious,mindist,cputime] = unionSphere(data,mindradious);
		%返回mindradious数据：[序号+数据点dim+半径+隶属的hypersphere序号]
		%mindist少数类样本的距离矩阵
		
		uncoveredpoint = unique(mindradious(:,end));
		%合并后的剩余的hypersphere的序号
		
		drawUnionsphereFlag = 1;
		numofsphere = [];
		%返回每一个hypersphere包含的数据点
		for i=1:size(uncoveredpoint,1)
			j = uncoveredpoint(i);
			numofsphere = [numofsphere;sum(mindradious(:,end)==j)];
			if drawUnionsphereFlag == 1
				rectangle('Position',[mindradious(j,2)-mindradious(j,end-1),...
					mindradious(j,3)-mindradious(j,end-1),2*mindradious(j,end-1),...
						2*mindradious(j,end-1)],'Curvature',[1,1],'EdgeColor','r');
				axis equal;
				pause(2);
			end
		end
	%%%%%%%%%%%%%%%%合并后的hypersphere显示%%%%%%%%%%%%%%%%%%%%%%
	
	%%%%%%%%根据数据复杂度计算oversampling size%%%%%%%%%%%%%%%%%%
	%%%%%the complexity measure for the unbalanced dataset	
		complexitymeasure = length(uncoveredpoint)/size(data_allminority,1)
		
		finalmincenters = mindradious(uncoveredpoint,2:end-2);
		finalminradius  = mindradious(uncoveredpoint,end-1);
		complexitymeasure = 1;
		oversamplesize = ceil(complexitymeasure*(size(data_allmajority,1)-size(data_allminority,1)));
		
	%%%%%%%%%%为每一个hypersphere计算oversampling大小%%%%%%%%%%%%%%%%	
		alpha = 1;
		beta = 1;
		
		pi = exp(-alpha*finalminradius);
		%pj = 0;
		pj = exp(-beta*numofsphere);
		pi = (pi+pj)/sum(pi+pj)
		suboversampesizes = ceil(pi*oversamplesize)
	
	%%%%%显示每个合并后的hypersphere的oversampling大小%%%%%%%%
		drawNumFlag = 0;
		for i=1:size(uncoveredpoint,1)
			j = uncoveredpoint(i);
			if drawNumFlag == 1 
				text(mindradious(j,2),mindradious(j,3),...
				['   ' num2str(suboversampesizes(i))]);
				pause(2);
			end
			
		end
	

	%%%%%%%%%%%%%%生成minority样本%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		generatedX = [];
		%%显示生成的样本%%%%%%%%%%
		drawGenererizedInsFlag = 1;
		for i=1:size(uncoveredpoint,1)
			X = gnerandsphere(finalmincenters(i,:),dim,suboversampesizes(i),finalminradius(i)); % 2表示维数，50000表示样本数
			if drawGenererizedInsFlag == 1
				Xhandle = plot(X(:,1),  X(:,2), 'ks', 'LineWidth',2, 'MarkerSize', 5);
				pause(2);
			end	
			generatedX = [generatedX;X];
		end
		if drawGenererizedInsFlag == 1
			legend([Malhandle Minhandle,Xhandle],{'majority instances',...
		     'minority instances','generated minority instances'});
		end
		
		
		
		
		
		
		
		
	
		
		
		
		
	