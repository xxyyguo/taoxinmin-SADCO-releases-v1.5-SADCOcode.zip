function [dataradious,pddist,cputime] = unionSphere(data,dataradious)
%
% data-----[num-data x dim]  the data to be used to
%%dataradious-----[index,dim,dradius]
% pddist ----[num-data x num-data] distance matrix,
% dataradious ---num-data x[index,dim,dradius,unionclassid]

		tic
		pd = L2_dist(data,data);
		pddist = pd;
		%返回距离矩阵，自己类别
		
		[dummy,sortid] = sort(dataradious(:,end),'descend');
		sortdataradious = dataradious(sortid,:);%按照半径的大小从大到小排序
		flag = zeros(size(data,1),1);%标识是否处理完毕0未处理，也表示由谁包含
		
		for i = 1:size(sortdataradious,1)
			if flag(i) == 0 %没有处理，或者说没有被包含
				
				flag(i) = sortdataradious(i,1);%当前处理完毕，并标识所属
				leftindex = i+1:size(sortdataradious,1);
				leftindex = leftindex(flag(i+1:end)==0);%剩下的没处理的索引号
				leftunhandledid = sortdataradious(leftindex,1);%剩下的没处理的样本号
				
				leftdist = pd(sortdataradious(i,1),leftunhandledid)';%+sortdataradious(leftindex,4);
				%当样本号sortdataradious(i,1)和其他剩下的没处理的样本号之间的距离
				includedset = find(leftdist <= sortdataradious(i,4));
				%返回满足条件的序号
				if ~isempty(includedset)
					flag(leftindex(includedset)) = flag(i);
				end
			end
		end
		
		belongto = zeros(size(dataradious,1),1);
		belongto(sortdataradious(:,1)) = flag;
		dataradious = [dataradious,belongto];
		
		cputime = toc;