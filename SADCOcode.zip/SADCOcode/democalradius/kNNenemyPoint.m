function [minENNdist,minenemykneigor,majENNdist,majenemykneigor,majmindistmax,cputime] = ...
			kNNenemyPoint(mindata,majdata)
%只适合2类数据集
%test-----test data [num-test x dim]
% data-----[num-data x dim]  the data to be used to
%%k_nNum-nearest neighborhood number
% matrix,
% data ---NxM datasets
			k_nNum = 1;
			
			NT = size(mindata,1);
			NTNT = size(majdata,1);
			
			minENNdist= ones(NT,k_nNum)*inf;
			minenemykneigor = ones(NT,k_nNum)*inf;
			
			majENNdist= ones(NTNT,k_nNum)*inf;
			majenemykneigor = ones(NTNT,k_nNum)*inf;
			%这是个非常重要的变量，它可以使得距离矩阵变得非常稀疏
            
			            
			tic
			pd = L2_dist(mindata,majdata);
			 
			for i=1:NT    
						
						
						d=pd(i,:);
						
						
						min_id=[];
						for k=1:k_nNum
				 		    [tmp,id]=min(d);
				 		    d(id)=Inf;
						    min_id=[min_id id];
						end
						
						minENNdist(i,:) = pd(i,min_id);
						minenemykneigor(i,:) = min_id;
						
			end
			
			pd = pd';
			majmindistmax = pd;
			
			for i=1:NTNT    
						
						
						d=pd(i,:);
						
						
						min_id=[];
						for k=1:k_nNum
				 		    [tmp,id]=min(d);
				 		    d(id)=Inf;
						    min_id=[min_id id];
						end
						
						majENNdist(i,:) = pd(i,min_id);
						majenemykneigor(i,:) = min_id;
						
			end
			
			cputime = toc;
			
			
			
			